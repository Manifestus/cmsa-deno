-- CreateTable
CREATE TABLE "public"."bootstrap" (
    "id" UUID NOT NULL,
    "txt" TEXT NOT NULL,

    CONSTRAINT "bootstrap_pkey" PRIMARY KEY ("id")
);
